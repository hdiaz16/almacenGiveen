<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\ProductsModel;

class Products extends BaseController
{
	public $products;
	public $request;
	public $session;

	public function __construct($products = 0,$request = 0, $session = 0)
	{
		$this->products = new ProductsModel();
		$this->request = \Config\Services::request();
		$this->session = session();
	}

	public function products()
	{
		$data['name'] 	= $this->session->get('name');
		$data['email'] 	= $this->session->get('email');
		$data['img'] 	= $this->session->get('img');

		$data = [
			'name' 			=> $this->session->get('name'),
			'email' 		=> $this->session->get('email'),
			'img' 			=> $this->session->get('img'),
			'typeProduct' 	=> $this->products->type_of_producst(),
			'brand' 		=> $this->products->brands(),
			'contNet' 		=> $this->products->contNet()
		];
	
		$estructur =  view('main/header', $data ).view('products/addProducts', $data ).view('main/footer');
		return $estructur;
	}



	public function addProducts()
	{
		
		$data = [

			'id_marca' 			=> $this->request->getPostGet( 'marca' ),
			'id_tipo_producto' 	=> $this->request->getPostGet( 'tipoProducto' ),
			'id_cont_net' 		=> $this->request->getPostGet( 'contenidoNeto' ),
			'nombre' 			=> $this->request->getPostGet( 'nombre' ),
			'codigo'			=> $this->request->getPostGet( 'codigo' ),
			'cantidad' 			=> $this->request->getPostGet( 'cantidadPorPieza' ),
			'cantidad_min' 		=> $this->request->getPostGet( 'cantidadMinPorPieza' ),
			'cantidad_caja' 	=> $this->request->getPostGet( 'cantidadPorCaja' ),
			'ubicacion' 		=> $this->request->getPostGet( 'ubicacion' )
		];

		$data = $this->products->insert($data);

		if ( isset( $data ) ) {

			$result = array( 'error' => false, 'title' => "Producto guardado" ,'data' => "El producto se guardo correctamente" ); 
			echo json_encode( $result ); 
		}else{

			$result = array( 'error' => true, 'title' => "Hubo un problema" ,'data' => "El producto no se guardo correctamente, si el error persiste comunicate con el administardor " );
			echo json_encode( $result );

		}

		

		
	}

	//--------------------------------------------------------------------

}
