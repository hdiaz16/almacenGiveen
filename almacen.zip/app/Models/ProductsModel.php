<?php namespace App\Models;

use CodeIgniter\Model;

class ProductsModel extends Model
{
        protected $table      = 'tbl_products';
        protected $primaryKey = 'id';

        protected $returnType = 'array';
        protected $useSoftDeletes = true;

        protected $allowedFields = ['name'];

        protected $useTimestamps = true;
        protected $createdField  = 'created_at';
        protected $updatedField  = 'updated_at';
        protected $deletedField  = 'deleted';

        protected $validationRules    = [];
        protected $validationMessages = [];
        protected $skipValidation     = false;

        public $db;



        public function __construct($db=0)
        {
        	$this->db = \Config\Database::connect();
        }


        public function type_of_producst()
        {
            $query = $this->db->query(" SELECT * FROM ct_type_products ;" );
            return $query->getResult();
        }

        public function brands()
        {
            $query =  $this->db->query(" SELECT * FROM ct_brand_products ;" );
            return $query->getResult();
        }

        public function contNet()
        {
            $query =  $this->db->query(" SELECT * FROM ct_cont_net ;" );
            return $query->getResult();
        }

}