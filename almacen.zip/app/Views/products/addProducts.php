<div class="padding">
  <div class="row">
  	<div class="col-2"></div>

    <div class="col-md-8">
      <div class="box">
        <div class="box-header">
          <h2>Agregar Productos</h2>
          <small>Podras agregar todos los productos.</small>
        </div>
        
        <div class="box-body">
          <form role="form" id="formDataProducts" >

          	<div class="row">
          		<div class="col-6 ">
	          		<div class="md-form-group float-label">
		              	<input class="md-input " required="" name="codigo" id="codigo">
		              	<label>Codigo</label>
		            </div>
	          	</div>

	          	<div class="col-6 ">
	          		 <div class="md-form-group float-label">
		              	<input class="md-input" required="" name="nombre" id="nombre">
		              	<label>Nombre</label>
		            </div>
	          	</div>

	          	<div class="col-4 ">
	          		<div class="md-form-group float-label">
		             
		              	<select class="md-input" required="" name="marca" id="marca">
		              			<option > Seleccione una opcion</option>

		              		<?php foreach ($brand as $row) { ?>

		              			<option id="<?php echo $row->id ?>"> <?php echo $row->name; ?></option>

		              		<?php } ?>

		              	</select>
		              	<label>Marca</label>
		            </div>
	          	</div>

	          	<div class="col-4 ">
	          		<div class="md-form-group float-label">

		              	<select class="md-input" required="" name="tipoProducto" id="tipoProducto">
		              			<option > Seleccione una opcion</option>

		              		<?php foreach ($typeProduct as $row) { ?>

		              			<option id="<?php echo $row->id ?>"> <?php echo $row->name; ?></option>

		              		<?php } ?>

		              	</select>

		              	<label>Tipo de Producto</label>
		            </div>
	          	</div>

	          	<div class="col-4 ">
	          		<div class="md-form-group float-label">
		            
		         	 	<select class="md-input" required="" name="contenidoNeto" id="contenidoNeto">
		              			<option > Seleccione una opcion</option>

		              		<?php foreach ($contNet as $row) { ?>

		              			<option id="<?php echo $row->id ?>"> <?php echo $row->name; ?></option>

		              		<?php } ?>

		              	</select>

		              	<label> Contenido Neto</label>
		            </div>
	          	</div>

	          	<div class="col-6 ">
	          		<div class="md-form-group float-label">
		              <input class="md-input" required="" name="cantidad" id="cantidad">
		              <label>Cantidad (por pieza)</label>
		            </div>
	          	</div>

	          	<div class="col-6 ">
	          		<div class="md-form-group float-label">
		              <input class="md-input" required="" name="cantidadMinima" id="cantidadMinima">
		              <label>Cantidad minima (por pieza)</label>
		            </div>
	          	</div>

	          	<div class="col-6 ">
	          		<div class="md-form-group float-label">
		              <input class="md-input" required="" name="cantidadPorCaja" id="cantidadPorCaja">
		              <label>Cantidad por caja (catidad de piezas por caja)</label>
		            </div>
	          	</div>

	          	<div class="col-6 ">
	          		<div class="md-form-group float-label">
		              <input class="md-input" required="" name="ubicacion" id="ubicacion">
		              <label>Ubicacion</label>
		            </div>
	          	</div>

          	</div>
          
            <button type="button" class="btn m-b" id="addProducts">Guardar</button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</div>




<script src="libs/js/myjs/products.js"></script>